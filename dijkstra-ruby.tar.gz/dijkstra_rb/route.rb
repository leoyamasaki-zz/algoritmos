class Route
  def initialize(begin_node,end_node,distance)
		@begin_node=begin_node
		@end_node=end_node
		@distance=distance
	end
	def set_begin_node(node)
		@begin_node=node
	end
	def set_end_node(node)
		@end_node=node
	end
	def set_distance(distance)
		@distance=distance
	end
	def get_begin_node
		return @begin_node
	end
	def get_end_node
		return @end_node
	end
	def get_distance
		return @distance
	end
end
