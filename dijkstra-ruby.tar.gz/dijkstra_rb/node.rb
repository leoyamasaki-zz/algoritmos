require "label.rb"
class Node
  def initialize(id,name,accumulated,provenance,marked)
		@id=id
		@name=name
		@labels=[]
		lab= Label.new(accumulated,provenance)
		@labels << lab
		@marked=marked
	end
  
	def set_id(id)
		@id=id
	end
  
	def set_name(name)
		@name=name
	end
  
  def get_name
		return @name
	end

	def get_id
		return @id
	end
  
	def set_label(accumulated,provenance)
		@labels=[]
		lab= Label.new(accumulated,provenance)
		@labels << lab
	end
  
	def get_accumulated
		return @labels[0].get_accumulated
	end
  
	def get_provenance
		return @labels[0].get_provenance
	end
  
  def get_labels
    return @labels
  end
  
	def set_marked(mark)
		@marked=mark
	end
  
	def get_marked
		return @marked
	end
  
	def clear
    		@labels.clear
    		@labels << Label.new(0,0)
        @marked=false
	end
  
end
