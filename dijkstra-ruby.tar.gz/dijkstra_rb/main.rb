require "dijkstra.rb"

@d=Dijkstra.new
nodes=@d.load_list('metro.txt')

@d.begin_path('Potrero')
@d.end_path('Sevilla')

routes=@d.short_path

puts "De Potrero a Sevilla:"
routes.each do |r|
  puts r.get_name
end

puts "-------"

@d.begin_path('Santa Anita')
@d.end_path('El Rosario')

routes=@d.short_path

puts "De Santa Anita a El Rosario:"
routes.each do |r|
  puts r.get_name
end

puts "-------"

@d.begin_path('Ermita')
@d.end_path('Universidad')

routes=@d.short_path

puts "De Ermita a Universidad:"
routes.each do |r|
  puts r.get_name
end

