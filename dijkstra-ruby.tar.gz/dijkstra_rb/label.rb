class Label
  def initialize(accumulated,provenance)
		@accumulated=accumulated
		@provenance=provenance
	end
  def get_accumulated
    return @accumulated
  end
  def get_provenance
    return @provenance
  end
end
