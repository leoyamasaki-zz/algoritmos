require "node.rb"
require "route.rb"
class Dijkstra
  def generate_matrix(file)
    $matriz=[]
    for i in 0...148
      $matriz << Array.new
    end
    l=$matriz.length-1
    if File.exists?(file)
    	f=File.open(file)
    	i=0
    	f.each do |linea|
    		0.upto(l) do |j|
    			$matriz[i] << linea.split(",")[j]
    		end
    		i+=1
    	end
    	f.close
  	end	
  end
  
	def load_list(file)
    generate_matrix(file)
    l=$matriz.length
    @nodes=[]
		for i in 1...l
			node=Node.new(i-1,$matriz[0][i],0,0,false)
      @nodes << node
		end
    load_routes()
    return @nodes
	end

  def load_routes
    l=$matriz.length
    @routes=[]
    for i in 1...l
      for j in 1...l
        if $matriz[i][j] != "0" then
          route=Route.new(i-1,j-1,$matriz[i][j].to_i)
          @routes << route
        end
      end
    end
    return @routes
	end
  
  def node_search(name)
    @nodes.each do |node|
      return node if name==node.get_name
    end
  end
  
  def begin_path(node)
    @begin=node_search(node)
  end
  
  def end_path(node)
    @end=node_search(node)
  end
  
  def lower_label
    minor=0
    cond=false
    m=-1
    @nodes.each do |node|
      if node.get_accumulated>0 and !node.get_marked then
        if cond==false then
          minor=node.get_accumulated
          cond=true
          m=node.get_id
        end
        if node.get_accumulated < minor and !node.get_marked then
          minor=node.get_accumulated
          m=node.get_id
        end
      end
    end
    if m!=-1 then
      return @nodes[m]
    else
     return nil
    end
  end

  def generate_labels(nodebase)
    if nodebase then
      @nodes[nodebase.get_id].set_marked(true)
      @routes.each do |route|
        begin_node=route.get_begin_node
        end_node=route.get_end_node
        distance=route.get_distance
        if begin_node==nodebase.get_id and !@nodes[end_node].get_marked then
          if @nodes[end_node].get_accumulated==0 or ((distance+nodebase.get_accumulated) < @nodes[end_node].get_accumulated) then
            @nodes[end_node].set_label(distance+nodebase.get_accumulated,nodebase.get_id)
          end
        end
      end
      generate_labels(lower_label())
    end
  end

  def short_path
    clear
    generate_labels(@begin)
    routes=nodes_short_path(@end.get_id, @begin.get_id)
    routes=routes.flatten
    routes=routes.reverse
    return routes
  end
  
  def nodes_short_path(node, nodebase)
		short_path_nodes=[]
		@nodes[node].get_labels.each do |lab|
			if nodebase==lab.get_provenance then
				short_path_nodes << @nodes[node] 
			else
        short_path_nodes << @nodes[node] << nodes_short_path(lab.get_provenance,nodebase)
			end			
		end
		return short_path_nodes
	end
  
  def clear
    @nodes.each do |node|
      node.clear
    end
  end
  
end